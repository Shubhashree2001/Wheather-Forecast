- Designed and developed a user-friendly weather forecast app that provides real-time weather information and
forecasts.
– Implemented intuitive UI/UX for seamless navigation and integrated API for accurate data retrieval. Improved
user engagement through interactive features and customizable settings.
